function xmlOlvas() {
    var keres = new XMLHttpRequest();
    keres.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
			feldolgozXML(this.responseXML);
        }
    };
    keres.open("GET", "plant_catalog.xml", true);
    keres.send();
}

function feldolgozXML(data) {
	const plant_light_conditions = new Array();
	var min_price = 1000;
	var max_price = 0;
	var avg_price = 0;
	plants = data.getElementsByTagName("PLANT"); //PLANT tagnévből szedi ki az összes adatot
	for (var i=0; i<plants.length; i++) { //szokásos tömb hossz alapján számolás
		var plant_light_condition = plants[i].getElementsByTagName("LIGHT")[0]/*Tagnév alapján határozza meg hogy honnan szedi ki*/
		.childNodes[0]/*Kiszedi az elemet a light ból*/
		.nodeValue.toLowerCase();/*itt meg a node value-t kisbetűvé alakítja*/
		if (!plant_light_conditions.includes(plant_light_condition))
			plant_light_conditions.push(plant_light_condition);//beteszi a fő tömbbe a dolgokat
		
		var price = parseFloat/*át alakítja float típusúvá*/(plants[i].getElementsByTagName("PRICE")[0].childNodes[0].nodeValue.replace("$",""));/*A dollárt kiszedi és üressé teszi*/
		console.log(price);
		if (min_price > price)
			min_price = price;
		if (max_price < price)
			max_price = price;
		avg_price += price;
	}
	plant_light_conditions.sort();//ABC sorrendezés
	
	min_price = min_price.toFixed(2);//tizedes jegy mennyiségét határozza meg: 1.00 mert kettő van írva, de ha toFixed(1), akkor 1.0 lenne.
	max_price = max_price.toFixed(2);
	avg_price = (avg_price / plants.length).toFixed(2);//átlagár 
	
	document.getElementById("plant_light_conditions").innerHTML =
	"A növények számára ideális fényviszonyok:<br>" + plant_light_conditions.join(", ");//Ez a JavaScript kódrészlet egy HTML-elembe írja ki a növények számára ideális fényviszonyokat, vesszővel elválasztva.
	document.getElementById("prices").innerHTML = 
		"Minimum ár: " + min_price + " USD<br>" +
		"Maximum ár: " + max_price + " USD<br>" +
		"Átlag ár: " + avg_price + " USD";
	
	console.log(plant_light_conditions);
	console.log(min_price, max_price, avg_price);
}

function jsonOlvas() {
    var keres = new XMLHttpRequest();
    keres.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
			feldolgozJSON(this.responseText);
        }
    };
    keres.open("GET", "https://restcountries.com/v3.1/all", true);//valós link
    keres.send();
}

function feldolgozJSON(original_data) {
	const kiv_startOfWeek = document.getElementById("startOfWeek").value; //select option value értékét kéri le
	
	let data = JSON.parse(original_data); //data tömb létrehozása JSON ban
	console.log(data);
	var content = "";
	for (var i=0; i<data.length; i++) {
		var startOfWeek = data[i].startOfWeek;
		if (kiv_startOfWeek == "all" || kiv_startOfWeek == startOfWeek) {
			content += "<li>" + data[i].translations.hun.common + "</li>";	
		}
	}
	
	document.getElementById("countries").innerHTML = content;
}
