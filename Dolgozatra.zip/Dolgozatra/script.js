function beolvas(){
    var httpKeres = new XMLHttpRequest(); //Kötelező
    httpKeres.onreadystatechange = function() { //Kötelező
        if (this.readyState == 4 && this.status == 200) //leellenőrzi a kapcsolatot
            feldolgoz(this.responseText);   //Meghívja a function-t
    };
    httpKeres.open("GET", "data.csv", true);//Kötelező
    httpKeres.send();   //Kötelező
}

function feldolgoz(adat) {
    // Egyik megoldás
    var feldolgozott_adat = adat.replaceAll(";", " - "); //kicseréli a cuccokat ";"-ről "-"-re
    feldolgozott_adat = feldolgozott_adat.replaceAll("\n", "<br>");
    feldolgozott_adat = feldolgozott_adat.substring(0,63).toUpperCase() + feldolgozott_adat.substring(63);

    // Másik megoldás
    // var feldolgozott_adat_2 = adat.replaceAll(";", " - ");
    // sorok = feldolgozott_adat_2.split("\n");
    // sorok[0] = sorok[0].toUpperCase();
    // feldolgozott_adat_2 = sorok.join("<br>");

    document.getElementById("valasz").innerHTML = feldolgozott_adat;
}