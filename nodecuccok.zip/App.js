const express = require('express');
const cors = require('cors');
const mysql = require('mysql2');
const Config = require('../nodegyak/config');
const bodyParser = require('body-parser');
const app = express();
const port = 8000;


app.use(cors({ origin: '*' })); 
app.use(express.json()); 
app.use(bodyParser.json());

app.get('/', (req, res) => {
    res.send("<h1>Szerver fut</h1>")
})

app.get('/hello', (req, res) => {
    res.send("<h1>Szia</h1>")
})

app.get('/xyz/light', (req, res) => {
    var con = mysql.createConnection(new Config());

    // FIX: Use con.connect(), not con.connection()
    con.connect((err) => {
        if (err) {
            console.error('Database connection failed:', err);
            return res.status(500).send('Database connection error');
        }
        console.log('Sikeres csatlakozás a light-on');

        // Execute query inside the connect callback
        con.query("SELECT light FROM `noveny` GROUP BY 1;", (err, result) => {
            if (err) {
                console.error('Query error:', err);
                return res.status(500).send('Query execution error');
            }
            console.log(result);
            res.send(result);
        });

        // Close connection after query
        con.end();
    });
});

app.get('/xyz/all', (req, res) => {
    var con = mysql.createConnection(new Config());

    // FIX: Use con.connect(), not con.connection()
    con.connect((err) => {
        if (err) {
            console.error('Database connection failed:', err);
            return res.status(500).send('Database connection error');
        }
        console.log('Sikeres csatlakozás a all-on');

        // Execute query inside the connect callback
        con.query("SELECT * FROM `noveny`", (err, result) => {
            if (err) {
                console.error('Query error:', err);
                return res.status(500).send('Query execution error');
            }
            console.log(result);
            res.send(result);
        });

        // Close connection after query
        con.end();
    });
});

app.listen(port, () => {
    console.log(`Példa alkalmazás publikálva ${port}-on`);
})