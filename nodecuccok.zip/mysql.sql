-- Active: 1739897534351@@127.0.0.1@3306@novenyek

IF NOT EXISTS novenyek CREATE DATABASE novenyek DEFAULT CHARACTER SET "utf8" COLLATE "utf8_hungarian_ci";

CREATE Table noveny(
    nev VARCHAR(100),
    botanical VARCHAR(100),
    zona INT,
    light VARCHAR(40),
    ar INT,
    mennyiseg int
);

CREATE Table teszt(
    nev VARCHAR(100),
    igen VARCHAR(100),
    id INT
);

INSERT INTO noveny (nev, botanical, zona, light, ar, mennyiseg)  
VALUES  
    ('Bloodroot', 'Sanguinaria canadensis', 4, 'Mostly Shady', 2.44, 10),  
    ('Columbine', 'Aquilegia canadensis', 3, 'Mostly Shady', 9.37, 15),  
    ('Marsh Marigold', 'Caltha palustris', 4, 'Mostly Sunny', 6.81, 12),  
    ('Cowslip', 'Caltha palustris', 4, 'Mostly Shady', 9.90, 10),  
    ('Dutchman''s-Breeches', 'Dicentra cucullaria', 3, 'Mostly Shady', 6.44, 8),  
    ('Ginger, Wild', 'Asarum canadense', 3, 'Mostly Shady', 9.03, 20),  
    ('Hepatica', 'Hepatica americana', 4, 'Mostly Shady', 4.45, 14),  
    ('Liverleaf', 'Hepatica americana', 4, 'Mostly Shady', 3.99, 16),  
    ('Jack-In-The-Pulpit', 'Arisaema triphyllum', 4, 'Mostly Shady', 3.23, 10),  
    ('Mayapple', 'Podophyllum peltatum', 3, 'Mostly Shady', 2.98, 12),  
    ('Phlox, Woodland', 'Phlox divaricata', 3, 'Sun or Shade', 2.80, 18),  
    ('Phlox, Blue', 'Phlox divaricata', 3, 'Sun or Shade', 5.59, 10),  
    ('Spring-Beauty', 'Claytonia Virginica', 7, 'Mostly Shady', 6.59, 9),  
    ('Trillium', 'Trillium grandiflorum', 5, 'Sun or Shade', 3.90, 11),  
    ('Wake Robin', 'Trillium grandiflorum', 5, 'Sun or Shade', 3.20, 13),  
    ('Violet, Dog-Tooth', 'Erythronium americanum', 4, 'Shade', 9.04, 7),  
    ('Trout Lily', 'Erythronium americanum', 4, 'Shade', 6.94, 6),  
    ('Adder''s-Tongue', 'Erythronium americanum', 4, 'Shade', 9.58, 8),  
    ('Anemone', 'Anemone blanda', 6, 'Mostly Shady', 8.86, 10),  
    ('Grecian Windflower', 'Anemone blanda', 6, 'Mostly Shady', 9.16, 10),  
    ('Bee Balm', 'Monarda didyma', 4, 'Shade', 4.59, 14),  
    ('Bergamot', 'Monarda didyma', 4, 'Shade', 7.16, 10),  
    ('Black-Eyed Susan', 'Rudbeckia hirta', NULL, 'Sunny', 9.80, 5),  
    ('Buttercup', 'Ranunculus', 4, 'Shade', 2.57, 9),  
    ('Crowfoot', 'Ranunculus', 4, 'Shade', 9.34, 10),  
    ('Butterfly Weed', 'Asclepias tuberosa', NULL, 'Sunny', 2.78, 10),  
    ('Cinquefoil', 'Potentilla', NULL, 'Shade', 7.06, 10),  
    ('Primrose', 'Oenothera', 3, 'Sunny', 6.56, 12),  
    ('Gentian', 'Gentiana', 4, 'Sun or Shade', 7.81, 10),  
    ('Blue Gentian', 'Gentiana', 4, 'Sun or Shade', 8.56, 10),  
    ('Jacob''s Ladder', 'Polemonium caeruleum', NULL, 'Shade', 9.26, 10),  
    ('Greek Valerian', 'Polemonium caeruleum', NULL, 'Shade', 4.36, 10),  
    ('California Poppy', 'Eschscholzia californica', NULL, 'Sun', 7.89, 10),  
    ('Shooting Star', 'Dodecatheon', NULL, 'Mostly Shady', 8.60, 10),  
    ('Snakeroot', 'Cimicifuga', NULL, 'Shade', 5.63, 10),  
    ('Cardinal Flower', 'Lobelia cardinalis', 2, 'Shade', 3.02, 10);

    /*Lekérdezések*/

    SELECT light FROM `noveny` GROUP BY 1;