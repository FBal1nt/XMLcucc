function teszt(){
    fetch('http://localhost:8000/xyz/light')
    .then((response) => {
        return response.json();
    })
    .then(data => {
        console.log("1");
        console.log(data);
        var fenyek = document.getElementById("fenyek");
        var szoveg = "";
        data.forEach((light) => {
            console.log(light);
            szoveg += light.light + ", ";
        })
        szoveg.slice(0, -2);
        fenyek.innerHTML = szoveg;
    })
    .catch((err) => {
        console.error(err);
    });
}

function teszt2(){
    fetch('http://localhost:8000/xyz/all')
    .then((response) => {
        return response.json();
    })
    .then(data => {
        console.log(data);
        var all = document.getElementById("all");
        var szoveg = "";
        data.forEach((item) => {
            console.log("Neve: " + item.nev + ", Zóna: " + item.zona + ", Ár: " + item.ar);
        })
        all.innerHTML = szoveg;
    })
    .catch((err) => {
        console.error(err);
    });
}